#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#define __USE_BSD // make prototype for strdup visible
#include <string.h>

typedef struct linkedlist { // linked list of ints (for use in Node)
	int index;
	struct linkedlist *next;
} List;

typedef struct { // a Node of a Graph
	char *name;
	List *outlist; // adjacency list
	int outdegree; // length of outlist
	int indegree;
//double pagerank_score; //not needed for this exercise
} Node;

typedef struct {
	// your code goes here
	int MaxSize;
	Node *table;
} Graph;

/** -------------graph functions ---------------**/

int initialize_graph(Graph *mygraph, int MaxSize) {
	// your code goes here
	mygraph->MaxSize = MaxSize;
	mygraph->table = (Node *) calloc(sizeof(Node), MaxSize);
	for (int i = 0; i < MaxSize; i++) {
		mygraph->table[i].indegree = 0;
		mygraph->table[i].outdegree = 0;
	}

	return 0;
}
int insert_graph_node(Graph *mygraph, int n, char *name) {
	// your code goes here
	mygraph->table[n].name = strdup(name);

	return 0;

}
int insert_graph_link(Graph *mygraph, int source, int target) {
	// your code goes here
	List *targetList = (List*) malloc(sizeof(List));
	targetList->index = target;
	targetList->next = NULL;

	if (mygraph->table[source].outlist == NULL) {
		mygraph->table[source].outlist = targetList;
	}
	else
	{
		List *sourceList = mygraph->table[source].outlist;
		while (sourceList->next != NULL)
		 {
			sourceList = sourceList->next;
		}
		sourceList->next = targetList;
	}//else
	mygraph->table[target].indegree++;
	mygraph->table[source].outdegree++;

	return 0;
}

// use to check result of strdup, malloc etc.
void check(void *memory, char *message) {
	if (memory == NULL) {
		fprintf(stderr, "Can't allocate memory for %s\n", message);
		exit(3);
	}
}
int read_graph(Graph *mygraph, char *filename)
/*
 * Reads in graph from FILE *filename which is of .gx format.
 * Stores it as Graph in *mygraph.
 * Returns an error if file does not start with MAX command,
 * or if any subsequent line is not a NODE or EDGE command.
 * Does not check that node numbers do not exceed the maximum number
 * Defined by the MAX command.
 * 8/2/2010 - JLS
 */
{
	FILE *fp;
	char command[80], name[80];
	int i, s, t;
	fp = fopen(filename, "r");
	if (fp == NULL) {
		fprintf(stderr, "cannot open file %s\n", filename);
		return -1;
	}
	printf("Reading graph from %s\n", filename);
	fscanf(fp, "%s", command);
	if (strcmp(command, "MAX") != 0) {
		fprintf(stderr, "Error in graphics file format\n");
		return -1;
	} else {
		fscanf(fp, "%d", &i);
		initialize_graph(mygraph, i + 1); // +1 so nodes can be numbered 1..MAX
		while (fscanf(fp, "%s", command) != EOF) {
			if (strcmp(command, "NODE") == 0) {
				fscanf(fp, "%d %s", &i, name);
				insert_graph_node(mygraph, i, name);
			} else if (strcmp(command, "EDGE") == 0) {
				fscanf(fp, "%d %d", &s, &t);
				insert_graph_link(mygraph, s, t);
			} else
				return -1;
		}
	}
	return 0;
}
void print_graph(Graph *mygraph)
/*
 * Prints out Graph *mygraph to the stdout in .gx format.
 * 8/2/2010 - JLS
 */
{
	int i;
	List *current;
	printf("MAX %d\n", mygraph->MaxSize);
	for (i = 0; i < mygraph->MaxSize; i++)
		if (mygraph->table[i].name != NULL) {
			printf("NODE %d %s\n", i, mygraph->table[i].name);
			current = mygraph->table[i].outlist;
			while (current != NULL) {
				printf("EDGE %d %d\n", i, current->index);
				current = current->next;
			}
		}
}



/** -------------end of graph functions ---------------**/


/**----------------------pending----------------------**/
int done = 0;
int noNext = 0;

void pending(List *currentQueue, int rootNode, List *adjacents, int distance[],
		int visited[]) {
	//find the end of queue to append new node
	if (noNext == 0) {
		if (currentQueue->next != NULL) {
			pending(currentQueue->next, rootNode, adjacents, distance, visited);
		}
		noNext = 1;
	}
	//pending
	if (done == 0) {

		if (adjacents != NULL) {
			//if the distance of this node is infinity
			//which means the node is not append on queue
      //always set the distance of node is infinity at beginning
			if (distance[adjacents->index] == 0 &&visited[adjacents->index] != 1)
        {
				if (currentQueue->next == NULL)
        {
					currentQueue->next = (List *) malloc(sizeof(List));
				}
        //distance+1, add the adjacent into the currentQueue
				distance[adjacents->index] = distance[rootNode] + 1;
				currentQueue->next->index = adjacents->index;
			}
			//if the current distance of this node is greater than
			//distance from root node to it
			else if (distance[adjacents->index] != 0 && distance[adjacents->index] > distance[rootNode] + 1)
      {
				     distance[adjacents->index] = distance[rootNode] + 1;
			}

			if (adjacents->next != NULL)
      {
				if (currentQueue->next == NULL)
        {
					currentQueue->next = (List *) malloc(sizeof(List));
				}
        //recusive pending
				pending(currentQueue->next, rootNode, adjacents->next,distance, visited);
			}
		}

		done = 1;
	}
}





/** ------------- calculate average ------------**/
double averageDistance(Graph mygraph, int distance[], int visited[]){
	int startNode;
	double sum, average, averageSum;
	double finalAverage;

	for (int i = 1; i < mygraph.MaxSize; i++)
	{
	     startNode = i;

	     Dijkstra(mygraph, startNode, visited, distance);

	     sum = average = 0;
	     for(int i = 1; i < mygraph.MaxSize; i++)
			 {
	    	 sum += distance[i];
	     }
	     average = sum / mygraph.MaxSize;
	     printf("the average distances from node %s ", mygraph.table[startNode].name);
	     printf("to all other reachable node are: %f\n", average);

	     averageSum += average;
	     for (int i = 0; i < mygraph.MaxSize; i++)
			  {
	     	  visited[i] = 0;
	     	  distance[i] = 0;
	     }
    }
	finalAverage = averageSum / mygraph.MaxSize;

    return finalAverage;
}


/** ------------- Dijkstra ---------------**/
void Dijkstra(Graph graph, int rootNode, int visited[], int distance[]) {
	//create a priority queue and set first node on queue the start node
	List *theQueue = (List *) malloc(sizeof(List));
	theQueue->index = rootNode;

	//get all its adjacent which are nodes
	//with shortest distance to rootNode
	List *adjacents = graph.table[rootNode].outlist;

	//add root node and
	//node with shortest distance to rootNode (its adjacent node) into queue
	pending(theQueue, rootNode, adjacents, distance, visited);
	done = noNext = 0;

	//set distance of root node equals to 0
	distance[rootNode] = 0;
  //set rootNode is visited
	visited[rootNode] = 1;

	//root node of each adjacent pending
	int centreNode;

	while (theQueue->next != NULL) {
		//mark first node on heap visited
		visited[theQueue->index] = 1;
		//remove first node from queue
		theQueue = theQueue->next;

    //(Dijkstra)
    //the node with shortest distance to previous root node become root node
		//and get all its adjacent node which are node with shortest distance

		centreNode = theQueue->index;
		adjacents = graph.table[centreNode].outlist;

		pending(theQueue, centreNode, adjacents, distance, visited);
		done = noNext = 0;
	}

}
/** -------------end of Dijkstra ---------------**/



/** ------------- InItInList---------------**/
int IsItInList(Graph graph, int current,int target)
{
	while(graph.table[current].outlist!= NULL )
	{
		if(graph.table[current].outlist->index==target)
		{
			printf("fuck");
			return 1;
		}
		graph.table[current].outlist=graph.table[current].outlist->next;
    printf("bb\n");

	}
	return 0;
}

/** ------------- end of Inlist---------------**/

int largestOut(Graph graph,int current,int visited[])
{
	List *adjacents = (List*) malloc(sizeof(List));
  adjacents = graph.table[current].outlist;

	int MAXOUT=adjacents->index;
	//Let maxout be the unvisited node in current.outlist with largest outdegree
	while(adjacents!=NULL && visited[adjacents->next->index]==0)
	{
		printf("fkc1\n" );
		adjacents=adjacents->next;
		if(graph.table[adjacents->index].outdegree>graph.table[MAXOUT].outdegree)
		{
			printf("fkc2\n" );
			MAXOUT=adjacents->index;
		}
		printf("fkc3\n" );
		return MAXOUT;

	}
}


/** ------------- heuristic---------------**/
void Heuristic(Graph graph, int rootNode,int target,int visited[]) {

	int path[graph.MaxSize];
	int current=rootNode;
	int distance=0;
	List *list;
  //set rootNode is visited
	visited[rootNode] = 1;


	//while (TARGET not in CURRENT.OUTLIST) and (CURRENT.OUTLIST not empty)
	while(graph.table[current].outlist!=NULL && IsItInList(graph,rootNode,target)==0)
	{
		printf("T\n" );
		//CURRENT ← MAXOUT
		path[distance]=current;
		distance++;
    printf("T1\n" );
		current=largestOut(graph,current,visited);
		printf("T2\n" );
    visited[current]=1;

		list=graph.table[current].outlist;
		printf("T3\n" );

	}//while
	path[distance]=current;
	distance++;


	if(IsItInList(graph,rootNode,target)==1)
	{
		path[distance]=target;
		printf("The distance between Node:%d and Node:%d is %d \n",path[0],target,distance );
		printf("via  " );
		for(int i=0;i<distance;i++)
		{
			printf("node: %d",path[i]);
		}
	}
	else
		printf("There is no path between those points\n");

}
/** -------------end of heuristic ---------------**/


int main(int argc, char *argv[])
{
	Graph mygraph;

	read_graph(&mygraph, argv[1]);

	int visited[mygraph.MaxSize];
	int distance[mygraph.MaxSize];
	for (int i = 0; i < mygraph.MaxSize; i++)
	{
		visited[i] = 0;
		distance[i] = 0;
	}//for

//which want to executed
#define Test

//the shortest path between 2 points
#ifdef onePoint
  int startNode;
  printf("Which node you want to act as start point?\n" );
	scanf("%d", &startNode);

	Dijkstra(mygraph, startNode, visited, distance);

	printf("the distances from %d to all other reachable node are:\n",
			startNode);
	for (int i = 0; i < mygraph.MaxSize; i++)
	{
		if (distance[i] != 0)
		 {
			printf("node: %s distance: %i\n", mygraph.table[i].name, distance[i]);
		}
	}
#endif

//small world property
#ifdef whole
	double Average;
	Average = averageDistance(mygraph, distance, visited);
	printf("the average distances from any one node to all other nodes");
	printf("is %f", Average);
#endif


//heuristic find shortest distance between 2 points
#ifdef Test
int source;
int target;
printf("Which 2 nodes  you want to act as source and target?\n" );
scanf("%d %d", &source,&target );
Heuristic(mygraph, source, target, visited);
#endif


return 0;
}//main
